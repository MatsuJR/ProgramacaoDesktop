/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex5;

/**
 *
 * @author Junior
 */
public class Inteiro2 extends ex4.Inteiro{

    

    
    public int soma(int v){
        valor = valor + v;
        return valor;
    }

    public int subtrai(int v){
        valor = valor - v;
        return valor;
    }

    public int multiplicaPor(int v){
        valor = valor * v;
        return valor;
    }
    
    public int dividePor(int divisor){
        valor = valor / divisor;
        return valor;
    }
    
}

